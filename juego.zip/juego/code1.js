gdjs.loseCode = {};
gdjs.loseCode.GDNewTiledSpriteObjects1= [];
gdjs.loseCode.GDNewTiledSpriteObjects2= [];

gdjs.loseCode.conditionTrue_0 = {val:false};
gdjs.loseCode.condition0IsTrue_0 = {val:false};
gdjs.loseCode.condition1IsTrue_0 = {val:false};


gdjs.loseCode.eventsList0 = function(runtimeScene) {

{


gdjs.loseCode.condition0IsTrue_0.val = false;
{
gdjs.loseCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.loseCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}}

}


};

gdjs.loseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.loseCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.loseCode.GDNewTiledSpriteObjects2.length = 0;

gdjs.loseCode.eventsList0(runtimeScene);
return;

}

gdjs['loseCode'] = gdjs.loseCode;
