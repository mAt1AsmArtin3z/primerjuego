gdjs._49Code = {};
gdjs._49Code.forEachIndex3 = 0;

gdjs._49Code.forEachObjects3 = [];

gdjs._49Code.forEachTemporary3 = null;

gdjs._49Code.forEachTotalCount3 = 0;

gdjs._49Code.GDjugadorObjects1= [];
gdjs._49Code.GDjugadorObjects2= [];
gdjs._49Code.GDjugadorObjects3= [];
gdjs._49Code.GDjugadorObjects4= [];
gdjs._49Code.GDjugador2Objects1= [];
gdjs._49Code.GDjugador2Objects2= [];
gdjs._49Code.GDjugador2Objects3= [];
gdjs._49Code.GDjugador2Objects4= [];
gdjs._49Code.GDplataforma2Objects1= [];
gdjs._49Code.GDplataforma2Objects2= [];
gdjs._49Code.GDplataforma2Objects3= [];
gdjs._49Code.GDplataforma2Objects4= [];
gdjs._49Code.GDplataformaflotanteObjects1= [];
gdjs._49Code.GDplataformaflotanteObjects2= [];
gdjs._49Code.GDplataformaflotanteObjects3= [];
gdjs._49Code.GDplataformaflotanteObjects4= [];
gdjs._49Code.GDvistaObjects1= [];
gdjs._49Code.GDvistaObjects2= [];
gdjs._49Code.GDvistaObjects3= [];
gdjs._49Code.GDvistaObjects4= [];
gdjs._49Code.GDplataformaflotante4Objects1= [];
gdjs._49Code.GDplataformaflotante4Objects2= [];
gdjs._49Code.GDplataformaflotante4Objects3= [];
gdjs._49Code.GDplataformaflotante4Objects4= [];
gdjs._49Code.GDapareceObjects1= [];
gdjs._49Code.GDapareceObjects2= [];
gdjs._49Code.GDapareceObjects3= [];
gdjs._49Code.GDapareceObjects4= [];
gdjs._49Code.GDcaeObjects1= [];
gdjs._49Code.GDcaeObjects2= [];
gdjs._49Code.GDcaeObjects3= [];
gdjs._49Code.GDcaeObjects4= [];
gdjs._49Code.GDplataformaflotante2Objects1= [];
gdjs._49Code.GDplataformaflotante2Objects2= [];
gdjs._49Code.GDplataformaflotante2Objects3= [];
gdjs._49Code.GDplataformaflotante2Objects4= [];
gdjs._49Code.GDplatflotEObjects1= [];
gdjs._49Code.GDplatflotEObjects2= [];
gdjs._49Code.GDplatflotEObjects3= [];
gdjs._49Code.GDplatflotEObjects4= [];
gdjs._49Code.GDtrolObjects1= [];
gdjs._49Code.GDtrolObjects2= [];
gdjs._49Code.GDtrolObjects3= [];
gdjs._49Code.GDtrolObjects4= [];
gdjs._49Code.GDplataformaflotantehObjects1= [];
gdjs._49Code.GDplataformaflotantehObjects2= [];
gdjs._49Code.GDplataformaflotantehObjects3= [];
gdjs._49Code.GDplataformaflotantehObjects4= [];
gdjs._49Code.GDplataformaflotanteFObjects1= [];
gdjs._49Code.GDplataformaflotanteFObjects2= [];
gdjs._49Code.GDplataformaflotanteFObjects3= [];
gdjs._49Code.GDplataformaflotanteFObjects4= [];
gdjs._49Code.GDplataforma1Objects1= [];
gdjs._49Code.GDplataforma1Objects2= [];
gdjs._49Code.GDplataforma1Objects3= [];
gdjs._49Code.GDplataforma1Objects4= [];
gdjs._49Code.GDpuasObjects1= [];
gdjs._49Code.GDpuasObjects2= [];
gdjs._49Code.GDpuasObjects3= [];
gdjs._49Code.GDpuasObjects4= [];
gdjs._49Code.GDplayerhitboxObjects1= [];
gdjs._49Code.GDplayerhitboxObjects2= [];
gdjs._49Code.GDplayerhitboxObjects3= [];
gdjs._49Code.GDplayerhitboxObjects4= [];
gdjs._49Code.GDluzObjects1= [];
gdjs._49Code.GDluzObjects2= [];
gdjs._49Code.GDluzObjects3= [];
gdjs._49Code.GDluzObjects4= [];
gdjs._49Code.GDiluminacion3Objects1= [];
gdjs._49Code.GDiluminacion3Objects2= [];
gdjs._49Code.GDiluminacion3Objects3= [];
gdjs._49Code.GDiluminacion3Objects4= [];
gdjs._49Code.GDbgObjects1= [];
gdjs._49Code.GDbgObjects2= [];
gdjs._49Code.GDbgObjects3= [];
gdjs._49Code.GDbgObjects4= [];
gdjs._49Code.GDbaseObjects1= [];
gdjs._49Code.GDbaseObjects2= [];
gdjs._49Code.GDbaseObjects3= [];
gdjs._49Code.GDbaseObjects4= [];
gdjs._49Code.GDpenduloObjects1= [];
gdjs._49Code.GDpenduloObjects2= [];
gdjs._49Code.GDpenduloObjects3= [];
gdjs._49Code.GDpenduloObjects4= [];
gdjs._49Code.GDsierraObjects1= [];
gdjs._49Code.GDsierraObjects2= [];
gdjs._49Code.GDsierraObjects3= [];
gdjs._49Code.GDsierraObjects4= [];
gdjs._49Code.GDsierra2Objects1= [];
gdjs._49Code.GDsierra2Objects2= [];
gdjs._49Code.GDsierra2Objects3= [];
gdjs._49Code.GDsierra2Objects4= [];
gdjs._49Code.GDbrilloObjects1= [];
gdjs._49Code.GDbrilloObjects2= [];
gdjs._49Code.GDbrilloObjects3= [];
gdjs._49Code.GDbrilloObjects4= [];
gdjs._49Code.GDbrillo2Objects1= [];
gdjs._49Code.GDbrillo2Objects2= [];
gdjs._49Code.GDbrillo2Objects3= [];
gdjs._49Code.GDbrillo2Objects4= [];
gdjs._49Code.GDarmaObjects1= [];
gdjs._49Code.GDarmaObjects2= [];
gdjs._49Code.GDarmaObjects3= [];
gdjs._49Code.GDarmaObjects4= [];
gdjs._49Code.GDganasteObjects1= [];
gdjs._49Code.GDganasteObjects2= [];
gdjs._49Code.GDganasteObjects3= [];
gdjs._49Code.GDganasteObjects4= [];
gdjs._49Code.GDdianaObjects1= [];
gdjs._49Code.GDdianaObjects2= [];
gdjs._49Code.GDdianaObjects3= [];
gdjs._49Code.GDdianaObjects4= [];
gdjs._49Code.GDNewTextObjects1= [];
gdjs._49Code.GDNewTextObjects2= [];
gdjs._49Code.GDNewTextObjects3= [];
gdjs._49Code.GDNewTextObjects4= [];
gdjs._49Code.GDpuertaObjects1= [];
gdjs._49Code.GDpuertaObjects2= [];
gdjs._49Code.GDpuertaObjects3= [];
gdjs._49Code.GDpuertaObjects4= [];
gdjs._49Code.GDNewParticlesEmitterObjects1= [];
gdjs._49Code.GDNewParticlesEmitterObjects2= [];
gdjs._49Code.GDNewParticlesEmitterObjects3= [];
gdjs._49Code.GDNewParticlesEmitterObjects4= [];
gdjs._49Code.GDNewSpriteObjects1= [];
gdjs._49Code.GDNewSpriteObjects2= [];
gdjs._49Code.GDNewSpriteObjects3= [];
gdjs._49Code.GDNewSpriteObjects4= [];
gdjs._49Code.GDNewSprite2Objects1= [];
gdjs._49Code.GDNewSprite2Objects2= [];
gdjs._49Code.GDNewSprite2Objects3= [];
gdjs._49Code.GDNewSprite2Objects4= [];
gdjs._49Code.GDNewSprite3Objects1= [];
gdjs._49Code.GDNewSprite3Objects2= [];
gdjs._49Code.GDNewSprite3Objects3= [];
gdjs._49Code.GDNewSprite3Objects4= [];
gdjs._49Code.GDshurikenObjects1= [];
gdjs._49Code.GDshurikenObjects2= [];
gdjs._49Code.GDshurikenObjects3= [];
gdjs._49Code.GDshurikenObjects4= [];

gdjs._49Code.conditionTrue_0 = {val:false};
gdjs._49Code.condition0IsTrue_0 = {val:false};
gdjs._49Code.condition1IsTrue_0 = {val:false};
gdjs._49Code.condition2IsTrue_0 = {val:false};
gdjs._49Code.conditionTrue_1 = {val:false};
gdjs._49Code.condition0IsTrue_1 = {val:false};
gdjs._49Code.condition1IsTrue_1 = {val:false};
gdjs._49Code.condition2IsTrue_1 = {val:false};


gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDvistaObjects2Objects = Hashtable.newFrom({"vista": gdjs._49Code.GDvistaObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataforma2Objects2Objects = Hashtable.newFrom({"plataforma2": gdjs._49Code.GDplataforma2Objects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDpuertaObjects2Objects = Hashtable.newFrom({"puerta": gdjs._49Code.GDpuertaObjects2});
gdjs._49Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._49Code.GDplayerhitboxObjects2, gdjs._49Code.GDplayerhitboxObjects3);


gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects3.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects3[k] = gdjs._49Code.GDplayerhitboxObjects3[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects3.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects3);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects3.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(gdjs._49Code.GDplayerhitboxObjects2, gdjs._49Code.GDplayerhitboxObjects3);


gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects3.length;i<l;++i) {
    if ( !(gdjs._49Code.GDplayerhitboxObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects3[k] = gdjs._49Code.GDplayerhitboxObjects3[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects3.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects3);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects3.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects3[i].setAnimation(0);
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects3);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects3.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs._49Code.GDjugadorObjects3.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects3[i].flipX(true);
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects2);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects2.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs._49Code.GDjugadorObjects2.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects2[i].flipX(false);
}
}}

}


};gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs._49Code.GDarmaObjects1});
gdjs._49Code.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs._49Code.GDjugadorObjects1 */
/* Reuse gdjs._49Code.GDplayerhitboxObjects1 */

gdjs._49Code.condition0IsTrue_0.val = false;
gdjs._49Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects1[i].getBehavior("PlatformerObject").isUsingControl("Down") ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects1[k] = gdjs._49Code.GDplayerhitboxObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects1.length = k;}if ( gdjs._49Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._49Code.GDjugadorObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDjugadorObjects1[i].isFlippedX() ) {
        gdjs._49Code.condition1IsTrue_0.val = true;
        gdjs._49Code.GDjugadorObjects1[k] = gdjs._49Code.GDjugadorObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDjugadorObjects1.length = k;}}
if (gdjs._49Code.condition1IsTrue_0.val) {
/* Reuse gdjs._49Code.GDarmaObjects1 */
{for(var i = 0, len = gdjs._49Code.GDarmaObjects1.length ;i < len;++i) {
    gdjs._49Code.GDarmaObjects1[i].getBehavior("Physics2").setLinearVelocityX(-(690));
}
}}

}


};gdjs._49Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects2[k] = gdjs._49Code.GDplayerhitboxObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects2.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects2[k] = gdjs._49Code.GDplayerhitboxObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects2.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects2);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects2.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects2[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects2[k] = gdjs._49Code.GDplayerhitboxObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects2.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects2);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects2.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects2[i].setAnimation(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
gdjs._49Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects1[i].getBehavior("PlatformerObject").isUsingControl("Down") ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects1[k] = gdjs._49Code.GDplayerhitboxObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects1.length = k;}if ( gdjs._49Code.condition0IsTrue_0.val ) {
{
{gdjs._49Code.conditionTrue_1 = gdjs._49Code.condition1IsTrue_0;
gdjs._49Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9169204);
}
}}
if (gdjs._49Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects1);
gdjs._49Code.GDarmaObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDarmaObjects1Objects, (( gdjs._49Code.GDjugadorObjects1.length === 0 ) ? 0 :gdjs._49Code.GDjugadorObjects1[0].getPointX("")) + 20, (( gdjs._49Code.GDjugadorObjects1.length === 0 ) ? 0 :gdjs._49Code.GDjugadorObjects1[0].getPointY("")) + 20, "");
}{for(var i = 0, len = gdjs._49Code.GDarmaObjects1.length ;i < len;++i) {
    gdjs._49Code.GDarmaObjects1[i].setZOrder((( gdjs._49Code.GDjugadorObjects1.length === 0 ) ? 0 :gdjs._49Code.GDjugadorObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs._49Code.GDarmaObjects1.length ;i < len;++i) {
    gdjs._49Code.GDarmaObjects1[i].getBehavior("Physics2").setLinearVelocityX(690);
}
}
{ //Subevents
gdjs._49Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs._49Code.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("iluminacion3"), gdjs._49Code.GDiluminacion3Objects2);
gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects2);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
{for(var i = 0, len = gdjs._49Code.GDjugadorObjects2.length ;i < len;++i) {
    gdjs._49Code.GDjugadorObjects2[i].setPosition((( gdjs._49Code.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs._49Code.GDplayerhitboxObjects2[0].getPointX("")),(( gdjs._49Code.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs._49Code.GDplayerhitboxObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs._49Code.GDplayerhitboxObjects2.length ;i < len;++i) {
    gdjs._49Code.GDplayerhitboxObjects2[i].hide();
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs._49Code.GDjugadorObjects2.length === 0 ) ? 0 :gdjs._49Code.GDjugadorObjects2[0].getPointX("")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs._49Code.GDjugadorObjects2.length === 0 ) ? 0 :gdjs._49Code.GDjugadorObjects2[0].getPointY("")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.6, "", 0);
}{for(var i = 0, len = gdjs._49Code.GDiluminacion3Objects2.length ;i < len;++i) {
    gdjs._49Code.GDiluminacion3Objects2[i].setRadius(gdjs.randomInRange(200, 250));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("vista"), gdjs._49Code.GDvistaObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDvistaObjects2Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador2"), gdjs._49Code.GDjugador2Objects2);
{for(var i = 0, len = gdjs._49Code.GDjugador2Objects2.length ;i < len;++i) {
    gdjs._49Code.GDjugador2Objects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataforma2"), gdjs._49Code.GDplataforma2Objects2);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataforma2Objects2Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("jugador2"), gdjs._49Code.GDjugador2Objects2);
{for(var i = 0, len = gdjs._49Code.GDjugador2Objects2.length ;i < len;++i) {
    gdjs._49Code.GDjugador2Objects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("puerta"), gdjs._49Code.GDpuertaObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
gdjs._49Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplayerhitboxObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplayerhitboxObjects2[i].getBehavior("PlatformerObject").isUsingControl("Jump") ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplayerhitboxObjects2[k] = gdjs._49Code.GDplayerhitboxObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplayerhitboxObjects2.length = k;}if ( gdjs._49Code.condition0IsTrue_0.val ) {
{
gdjs._49Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDpuertaObjects2Objects, false, runtimeScene, false);
}}
if (gdjs._49Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "muerte", false);
}}

}


{


gdjs._49Code.eventsList2(runtimeScene);
}


};gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects3Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects3});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDtrolObjects3Objects = Hashtable.newFrom({"trol": gdjs._49Code.GDtrolObjects3});
gdjs._49Code.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("trol"), gdjs._49Code.GDtrolObjects3);
{for(var i = 0, len = gdjs._49Code.GDtrolObjects3.length ;i < len;++i) {
    gdjs._49Code.GDtrolObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects3);
gdjs.copyArray(runtimeScene.getObjects("trol"), gdjs._49Code.GDtrolObjects3);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects3Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDtrolObjects3Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDtrolObjects3 */
{for(var i = 0, len = gdjs._49Code.GDtrolObjects3.length ;i < len;++i) {
    gdjs._49Code.GDtrolObjects3[i].hide(false);
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("aparece"), gdjs._49Code.GDapareceObjects2);
{for(var i = 0, len = gdjs._49Code.GDapareceObjects2.length ;i < len;++i) {
    gdjs._49Code.GDapareceObjects2[i].hide();
}
}}

}


};gdjs._49Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteh"), gdjs._49Code.GDplataformaflotantehObjects3);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotantehObjects3.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotantehObjects3[i].getX() <= 127 ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotantehObjects3[k] = gdjs._49Code.GDplataformaflotantehObjects3[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotantehObjects3.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDplataformaflotantehObjects3 */
{for(var i = 0, len = gdjs._49Code.GDplataformaflotantehObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotantehObjects3[i].returnVariable(gdjs._49Code.GDplataformaflotantehObjects3[i].getVariables().getFromIndex(0)).setString("right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteh"), gdjs._49Code.GDplataformaflotantehObjects3);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotantehObjects3.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotantehObjects3[i].getX() >= 700 ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotantehObjects3[k] = gdjs._49Code.GDplataformaflotantehObjects3[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotantehObjects3.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDplataformaflotantehObjects3 */
{for(var i = 0, len = gdjs._49Code.GDplataformaflotantehObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotantehObjects3[i].returnVariable(gdjs._49Code.GDplataformaflotantehObjects3[i].getVariables().getFromIndex(0)).setString("left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteh"), gdjs._49Code.GDplataformaflotantehObjects3);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotantehObjects3.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotantehObjects3[i].getVariableString(gdjs._49Code.GDplataformaflotantehObjects3[i].getVariables().getFromIndex(0)) == "right" ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotantehObjects3[k] = gdjs._49Code.GDplataformaflotantehObjects3[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotantehObjects3.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDplataformaflotantehObjects3 */
{for(var i = 0, len = gdjs._49Code.GDplataformaflotantehObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotantehObjects3[i].setX(gdjs._49Code.GDplataformaflotantehObjects3[i].getX() + (5));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteh"), gdjs._49Code.GDplataformaflotantehObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotantehObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotantehObjects2[i].getVariableString(gdjs._49Code.GDplataformaflotantehObjects2[i].getVariables().getFromIndex(0)) == "left" ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotantehObjects2[k] = gdjs._49Code.GDplataformaflotantehObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotantehObjects2.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDplataformaflotantehObjects2 */
{for(var i = 0, len = gdjs._49Code.GDplataformaflotantehObjects2.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotantehObjects2[i].setX(gdjs._49Code.GDplataformaflotantehObjects2[i].getX() - (5));
}
}}

}


};gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDjugadorObjects2Objects = Hashtable.newFrom({"jugador": gdjs._49Code.GDjugadorObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataformaflotanteFObjects2Objects = Hashtable.newFrom({"plataformaflotanteF": gdjs._49Code.GDplataformaflotanteFObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataformaflotanteFObjects3Objects = Hashtable.newFrom({"plataformaflotanteF": gdjs._49Code.GDplataformaflotanteFObjects3});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDjugadorObjects3Objects = Hashtable.newFrom({"jugador": gdjs._49Code.GDjugadorObjects3});
gdjs._49Code.eventsList6 = function(runtimeScene) {

};gdjs._49Code.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs._49Code.GDplataformaflotanteFObjects2 */

for(gdjs._49Code.forEachIndex3 = 0;gdjs._49Code.forEachIndex3 < gdjs._49Code.GDplataformaflotanteFObjects2.length;++gdjs._49Code.forEachIndex3) {
gdjs.copyArray(gdjs._49Code.GDjugadorObjects2, gdjs._49Code.GDjugadorObjects3);

gdjs._49Code.GDplataformaflotanteFObjects3.length = 0;


gdjs._49Code.forEachTemporary3 = gdjs._49Code.GDplataformaflotanteFObjects2[gdjs._49Code.forEachIndex3];
gdjs._49Code.GDplataformaflotanteFObjects3.push(gdjs._49Code.forEachTemporary3);
gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataformaflotanteFObjects3Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDjugadorObjects3Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setVariableBoolean(gdjs._49Code.GDplataformaflotanteFObjects3[i].getVariables().getFromIndex(1), true);
}
}}
}

}


};gdjs._49Code.eventsList8 = function(runtimeScene) {

{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.10;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(-(2));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.20;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(+(2));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.30;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(-(1.5));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.40;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(+(1.5));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.50;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(-(1));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.60;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(+(1));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.70;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(-(0.5));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.80;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].setAngle(+(0.5));
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 0.90;
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs._49Code.GDplataformaflotanteFObjects2, gdjs._49Code.GDplataformaflotanteFObjects3);

{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects3.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects3[i].addPolarForce(90, 200, 1);
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pf") > 1;
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "pf");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "pf");
}}

}


};gdjs._49Code.eventsList9 = function(runtimeScene) {

{



}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "pf");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("jugador"), gdjs._49Code.GDjugadorObjects2);
gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteF"), gdjs._49Code.GDplataformaflotanteFObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
gdjs._49Code.condition1IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDjugadorObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplataformaflotanteFObjects2Objects, false, runtimeScene, false);
}if ( gdjs._49Code.condition0IsTrue_0.val ) {
{
{gdjs._49Code.conditionTrue_1 = gdjs._49Code.condition1IsTrue_0;
gdjs._49Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9178132);
}
}}
if (gdjs._49Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "pf");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "pf");
}
{ //Subevents
gdjs._49Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteF"), gdjs._49Code.GDplataformaflotanteFObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotanteFObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotanteFObjects2[i].getVariableBoolean(gdjs._49Code.GDplataformaflotanteFObjects2[i].getVariables().getFromIndex(1), true) ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotanteFObjects2[k] = gdjs._49Code.GDplataformaflotanteFObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotanteFObjects2.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._49Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("plataformaflotanteF"), gdjs._49Code.GDplataformaflotanteFObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDplataformaflotanteFObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDplataformaflotanteFObjects1[i].getY() >= 900 ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDplataformaflotanteFObjects1[k] = gdjs._49Code.GDplataformaflotanteFObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDplataformaflotanteFObjects1.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDplataformaflotanteFObjects1 */
{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects1.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects1.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects1[i].setY((gdjs.RuntimeObject.getVariableNumber(gdjs._49Code.GDplataformaflotanteFObjects1[i].getVariables().get("pf"))));
}
}{for(var i = 0, len = gdjs._49Code.GDplataformaflotanteFObjects1.length ;i < len;++i) {
    gdjs._49Code.GDplataformaflotanteFObjects1[i].setVariableBoolean(gdjs._49Code.GDplataformaflotanteFObjects1[i].getVariables().getFromIndex(1), false);
}
}}

}


};gdjs._49Code.eventsList10 = function(runtimeScene) {

{


gdjs._49Code.eventsList4(runtimeScene);
}


{


gdjs._49Code.eventsList5(runtimeScene);
}


{


gdjs._49Code.eventsList9(runtimeScene);
}


};gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDsierra2Objects2Objects = Hashtable.newFrom({"sierra2": gdjs._49Code.GDsierra2Objects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDsierraObjects2Objects = Hashtable.newFrom({"sierra": gdjs._49Code.GDsierraObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs._49Code.GDplayerhitboxObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDpuasObjects2Objects = Hashtable.newFrom({"puas": gdjs._49Code.GDpuasObjects2});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs._49Code.GDarmaObjects1});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDdianaObjects1Objects = Hashtable.newFrom({"diana": gdjs._49Code.GDdianaObjects1});
gdjs._49Code.eventsList11 = function(runtimeScene) {

{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("pendulo"), gdjs._49Code.GDpenduloObjects2);
{for(var i = 0, len = gdjs._49Code.GDpenduloObjects2.length ;i < len;++i) {
    gdjs._49Code.GDpenduloObjects2[i].getBehavior("Physics2").applyAngularImpulse(0.9);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("brillo"), gdjs._49Code.GDbrilloObjects2);
gdjs.copyArray(runtimeScene.getObjects("brillo2"), gdjs._49Code.GDbrillo2Objects2);
gdjs.copyArray(runtimeScene.getObjects("pendulo"), gdjs._49Code.GDpenduloObjects2);
gdjs.copyArray(runtimeScene.getObjects("sierra"), gdjs._49Code.GDsierraObjects2);
gdjs.copyArray(runtimeScene.getObjects("sierra2"), gdjs._49Code.GDsierra2Objects2);
{for(var i = 0, len = gdjs._49Code.GDpenduloObjects2.length ;i < len;++i) {
    gdjs._49Code.GDpenduloObjects2[i].getBehavior("Physics2").addRevoluteJoint((gdjs._49Code.GDpenduloObjects2[i].getPointX("ancla")), (gdjs._49Code.GDpenduloObjects2[i].getPointY("ancla")), false, 0, 0, 0, false, 0, 0, gdjs.VariablesContainer.badVariable);
}
}{for(var i = 0, len = gdjs._49Code.GDsierraObjects2.length ;i < len;++i) {
    gdjs._49Code.GDsierraObjects2[i].rotate(220, runtimeScene);
}
}{for(var i = 0, len = gdjs._49Code.GDbrilloObjects2.length ;i < len;++i) {
    gdjs._49Code.GDbrilloObjects2[i].rotate(-(200), runtimeScene);
}
}{for(var i = 0, len = gdjs._49Code.GDsierraObjects2.length ;i < len;++i) {
    gdjs._49Code.GDsierraObjects2[i].setPosition((( gdjs._49Code.GDpenduloObjects2.length === 0 ) ? 0 :gdjs._49Code.GDpenduloObjects2[0].getPointX("inferior")) - (gdjs._49Code.GDsierraObjects2[i].getWidth()) / 2,(( gdjs._49Code.GDpenduloObjects2.length === 0 ) ? 0 :gdjs._49Code.GDpenduloObjects2[0].getPointY("inferior")) - (gdjs._49Code.GDsierraObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs._49Code.GDbrilloObjects2.length ;i < len;++i) {
    gdjs._49Code.GDbrilloObjects2[i].setPosition((( gdjs._49Code.GDsierraObjects2.length === 0 ) ? 0 :gdjs._49Code.GDsierraObjects2[0].getPointX("Center")) - (gdjs._49Code.GDbrilloObjects2[i].getWidth()) / 2,(( gdjs._49Code.GDsierraObjects2.length === 0 ) ? 0 :gdjs._49Code.GDsierraObjects2[0].getPointY("Center")) - (gdjs._49Code.GDbrilloObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs._49Code.GDbrillo2Objects2.length ;i < len;++i) {
    gdjs._49Code.GDbrillo2Objects2[i].rotate(-(200), runtimeScene);
}
}{for(var i = 0, len = gdjs._49Code.GDsierra2Objects2.length ;i < len;++i) {
    gdjs._49Code.GDsierra2Objects2[i].rotate(220, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("sierra2"), gdjs._49Code.GDsierra2Objects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDsierra2Objects2Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lose", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("sierra"), gdjs._49Code.GDsierraObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDsierraObjects2Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lose", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs._49Code.GDplayerhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("puas"), gdjs._49Code.GDpuasObjects2);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDplayerhitboxObjects2Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDpuasObjects2Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lose", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("arma"), gdjs._49Code.GDarmaObjects1);
gdjs.copyArray(runtimeScene.getObjects("diana"), gdjs._49Code.GDdianaObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDarmaObjects1Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDdianaObjects1Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("aparece"), gdjs._49Code.GDapareceObjects1);
gdjs.copyArray(runtimeScene.getObjects("cae"), gdjs._49Code.GDcaeObjects1);
gdjs.copyArray(runtimeScene.getObjects("shuriken"), gdjs._49Code.GDshurikenObjects1);
{for(var i = 0, len = gdjs._49Code.GDcaeObjects1.length ;i < len;++i) {
    gdjs._49Code.GDcaeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._49Code.GDapareceObjects1.length ;i < len;++i) {
    gdjs._49Code.GDapareceObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._49Code.GDshurikenObjects1.length ;i < len;++i) {
    gdjs._49Code.GDshurikenObjects1[i].hide();
}
}}

}


};gdjs._49Code.eventsList12 = function(runtimeScene) {

{


gdjs._49Code.eventsList11(runtimeScene);
}


};gdjs._49Code.eventsList13 = function(runtimeScene) {

{


{
}

}


{


gdjs._49Code.eventsList3(runtimeScene);
}


{


gdjs._49Code.eventsList10(runtimeScene);
}


{


gdjs._49Code.eventsList12(runtimeScene);
}


};

gdjs._49Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49Code.GDjugadorObjects1.length = 0;
gdjs._49Code.GDjugadorObjects2.length = 0;
gdjs._49Code.GDjugadorObjects3.length = 0;
gdjs._49Code.GDjugadorObjects4.length = 0;
gdjs._49Code.GDjugador2Objects1.length = 0;
gdjs._49Code.GDjugador2Objects2.length = 0;
gdjs._49Code.GDjugador2Objects3.length = 0;
gdjs._49Code.GDjugador2Objects4.length = 0;
gdjs._49Code.GDplataforma2Objects1.length = 0;
gdjs._49Code.GDplataforma2Objects2.length = 0;
gdjs._49Code.GDplataforma2Objects3.length = 0;
gdjs._49Code.GDplataforma2Objects4.length = 0;
gdjs._49Code.GDplataformaflotanteObjects1.length = 0;
gdjs._49Code.GDplataformaflotanteObjects2.length = 0;
gdjs._49Code.GDplataformaflotanteObjects3.length = 0;
gdjs._49Code.GDplataformaflotanteObjects4.length = 0;
gdjs._49Code.GDvistaObjects1.length = 0;
gdjs._49Code.GDvistaObjects2.length = 0;
gdjs._49Code.GDvistaObjects3.length = 0;
gdjs._49Code.GDvistaObjects4.length = 0;
gdjs._49Code.GDplataformaflotante4Objects1.length = 0;
gdjs._49Code.GDplataformaflotante4Objects2.length = 0;
gdjs._49Code.GDplataformaflotante4Objects3.length = 0;
gdjs._49Code.GDplataformaflotante4Objects4.length = 0;
gdjs._49Code.GDapareceObjects1.length = 0;
gdjs._49Code.GDapareceObjects2.length = 0;
gdjs._49Code.GDapareceObjects3.length = 0;
gdjs._49Code.GDapareceObjects4.length = 0;
gdjs._49Code.GDcaeObjects1.length = 0;
gdjs._49Code.GDcaeObjects2.length = 0;
gdjs._49Code.GDcaeObjects3.length = 0;
gdjs._49Code.GDcaeObjects4.length = 0;
gdjs._49Code.GDplataformaflotante2Objects1.length = 0;
gdjs._49Code.GDplataformaflotante2Objects2.length = 0;
gdjs._49Code.GDplataformaflotante2Objects3.length = 0;
gdjs._49Code.GDplataformaflotante2Objects4.length = 0;
gdjs._49Code.GDplatflotEObjects1.length = 0;
gdjs._49Code.GDplatflotEObjects2.length = 0;
gdjs._49Code.GDplatflotEObjects3.length = 0;
gdjs._49Code.GDplatflotEObjects4.length = 0;
gdjs._49Code.GDtrolObjects1.length = 0;
gdjs._49Code.GDtrolObjects2.length = 0;
gdjs._49Code.GDtrolObjects3.length = 0;
gdjs._49Code.GDtrolObjects4.length = 0;
gdjs._49Code.GDplataformaflotantehObjects1.length = 0;
gdjs._49Code.GDplataformaflotantehObjects2.length = 0;
gdjs._49Code.GDplataformaflotantehObjects3.length = 0;
gdjs._49Code.GDplataformaflotantehObjects4.length = 0;
gdjs._49Code.GDplataformaflotanteFObjects1.length = 0;
gdjs._49Code.GDplataformaflotanteFObjects2.length = 0;
gdjs._49Code.GDplataformaflotanteFObjects3.length = 0;
gdjs._49Code.GDplataformaflotanteFObjects4.length = 0;
gdjs._49Code.GDplataforma1Objects1.length = 0;
gdjs._49Code.GDplataforma1Objects2.length = 0;
gdjs._49Code.GDplataforma1Objects3.length = 0;
gdjs._49Code.GDplataforma1Objects4.length = 0;
gdjs._49Code.GDpuasObjects1.length = 0;
gdjs._49Code.GDpuasObjects2.length = 0;
gdjs._49Code.GDpuasObjects3.length = 0;
gdjs._49Code.GDpuasObjects4.length = 0;
gdjs._49Code.GDplayerhitboxObjects1.length = 0;
gdjs._49Code.GDplayerhitboxObjects2.length = 0;
gdjs._49Code.GDplayerhitboxObjects3.length = 0;
gdjs._49Code.GDplayerhitboxObjects4.length = 0;
gdjs._49Code.GDluzObjects1.length = 0;
gdjs._49Code.GDluzObjects2.length = 0;
gdjs._49Code.GDluzObjects3.length = 0;
gdjs._49Code.GDluzObjects4.length = 0;
gdjs._49Code.GDiluminacion3Objects1.length = 0;
gdjs._49Code.GDiluminacion3Objects2.length = 0;
gdjs._49Code.GDiluminacion3Objects3.length = 0;
gdjs._49Code.GDiluminacion3Objects4.length = 0;
gdjs._49Code.GDbgObjects1.length = 0;
gdjs._49Code.GDbgObjects2.length = 0;
gdjs._49Code.GDbgObjects3.length = 0;
gdjs._49Code.GDbgObjects4.length = 0;
gdjs._49Code.GDbaseObjects1.length = 0;
gdjs._49Code.GDbaseObjects2.length = 0;
gdjs._49Code.GDbaseObjects3.length = 0;
gdjs._49Code.GDbaseObjects4.length = 0;
gdjs._49Code.GDpenduloObjects1.length = 0;
gdjs._49Code.GDpenduloObjects2.length = 0;
gdjs._49Code.GDpenduloObjects3.length = 0;
gdjs._49Code.GDpenduloObjects4.length = 0;
gdjs._49Code.GDsierraObjects1.length = 0;
gdjs._49Code.GDsierraObjects2.length = 0;
gdjs._49Code.GDsierraObjects3.length = 0;
gdjs._49Code.GDsierraObjects4.length = 0;
gdjs._49Code.GDsierra2Objects1.length = 0;
gdjs._49Code.GDsierra2Objects2.length = 0;
gdjs._49Code.GDsierra2Objects3.length = 0;
gdjs._49Code.GDsierra2Objects4.length = 0;
gdjs._49Code.GDbrilloObjects1.length = 0;
gdjs._49Code.GDbrilloObjects2.length = 0;
gdjs._49Code.GDbrilloObjects3.length = 0;
gdjs._49Code.GDbrilloObjects4.length = 0;
gdjs._49Code.GDbrillo2Objects1.length = 0;
gdjs._49Code.GDbrillo2Objects2.length = 0;
gdjs._49Code.GDbrillo2Objects3.length = 0;
gdjs._49Code.GDbrillo2Objects4.length = 0;
gdjs._49Code.GDarmaObjects1.length = 0;
gdjs._49Code.GDarmaObjects2.length = 0;
gdjs._49Code.GDarmaObjects3.length = 0;
gdjs._49Code.GDarmaObjects4.length = 0;
gdjs._49Code.GDganasteObjects1.length = 0;
gdjs._49Code.GDganasteObjects2.length = 0;
gdjs._49Code.GDganasteObjects3.length = 0;
gdjs._49Code.GDganasteObjects4.length = 0;
gdjs._49Code.GDdianaObjects1.length = 0;
gdjs._49Code.GDdianaObjects2.length = 0;
gdjs._49Code.GDdianaObjects3.length = 0;
gdjs._49Code.GDdianaObjects4.length = 0;
gdjs._49Code.GDNewTextObjects1.length = 0;
gdjs._49Code.GDNewTextObjects2.length = 0;
gdjs._49Code.GDNewTextObjects3.length = 0;
gdjs._49Code.GDNewTextObjects4.length = 0;
gdjs._49Code.GDpuertaObjects1.length = 0;
gdjs._49Code.GDpuertaObjects2.length = 0;
gdjs._49Code.GDpuertaObjects3.length = 0;
gdjs._49Code.GDpuertaObjects4.length = 0;
gdjs._49Code.GDNewParticlesEmitterObjects1.length = 0;
gdjs._49Code.GDNewParticlesEmitterObjects2.length = 0;
gdjs._49Code.GDNewParticlesEmitterObjects3.length = 0;
gdjs._49Code.GDNewParticlesEmitterObjects4.length = 0;
gdjs._49Code.GDNewSpriteObjects1.length = 0;
gdjs._49Code.GDNewSpriteObjects2.length = 0;
gdjs._49Code.GDNewSpriteObjects3.length = 0;
gdjs._49Code.GDNewSpriteObjects4.length = 0;
gdjs._49Code.GDNewSprite2Objects1.length = 0;
gdjs._49Code.GDNewSprite2Objects2.length = 0;
gdjs._49Code.GDNewSprite2Objects3.length = 0;
gdjs._49Code.GDNewSprite2Objects4.length = 0;
gdjs._49Code.GDNewSprite3Objects1.length = 0;
gdjs._49Code.GDNewSprite3Objects2.length = 0;
gdjs._49Code.GDNewSprite3Objects3.length = 0;
gdjs._49Code.GDNewSprite3Objects4.length = 0;
gdjs._49Code.GDshurikenObjects1.length = 0;
gdjs._49Code.GDshurikenObjects2.length = 0;
gdjs._49Code.GDshurikenObjects3.length = 0;
gdjs._49Code.GDshurikenObjects4.length = 0;

gdjs._49Code.eventsList13(runtimeScene);
return;

}

gdjs['_49Code'] = gdjs._49Code;
