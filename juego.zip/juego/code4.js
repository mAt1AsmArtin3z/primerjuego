gdjs.victoriaCode = {};

gdjs.victoriaCode.conditionTrue_0 = {val:false};
gdjs.victoriaCode.condition0IsTrue_0 = {val:false};


gdjs.victoriaCode.eventsList0 = function(runtimeScene) {

};

gdjs.victoriaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.victoriaCode.eventsList0(runtimeScene);
return;

}

gdjs['victoriaCode'] = gdjs.victoriaCode;
