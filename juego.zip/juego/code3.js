gdjs.muerteCode = {};
gdjs.muerteCode.GDNewPanelSpriteObjects1= [];
gdjs.muerteCode.GDNewPanelSpriteObjects2= [];
gdjs.muerteCode.GDNewPanelSpriteObjects3= [];
gdjs.muerteCode.GDpisoObjects1= [];
gdjs.muerteCode.GDpisoObjects2= [];
gdjs.muerteCode.GDpisoObjects3= [];
gdjs.muerteCode.GDparedObjects1= [];
gdjs.muerteCode.GDparedObjects2= [];
gdjs.muerteCode.GDparedObjects3= [];
gdjs.muerteCode.GDpared2Objects1= [];
gdjs.muerteCode.GDpared2Objects2= [];
gdjs.muerteCode.GDpared2Objects3= [];
gdjs.muerteCode.GDpersonajeObjects1= [];
gdjs.muerteCode.GDpersonajeObjects2= [];
gdjs.muerteCode.GDpersonajeObjects3= [];
gdjs.muerteCode.GDNewSprite2Objects1= [];
gdjs.muerteCode.GDNewSprite2Objects2= [];
gdjs.muerteCode.GDNewSprite2Objects3= [];
gdjs.muerteCode.GDNewTextObjects1= [];
gdjs.muerteCode.GDNewTextObjects2= [];
gdjs.muerteCode.GDNewTextObjects3= [];
gdjs.muerteCode.GDarmaObjects1= [];
gdjs.muerteCode.GDarmaObjects2= [];
gdjs.muerteCode.GDarmaObjects3= [];
gdjs.muerteCode.GDpouObjects1= [];
gdjs.muerteCode.GDpouObjects2= [];
gdjs.muerteCode.GDpouObjects3= [];
gdjs.muerteCode.GDNewText2Objects1= [];
gdjs.muerteCode.GDNewText2Objects2= [];
gdjs.muerteCode.GDNewText2Objects3= [];
gdjs.muerteCode.GDvidaObjects1= [];
gdjs.muerteCode.GDvidaObjects2= [];
gdjs.muerteCode.GDvidaObjects3= [];
gdjs.muerteCode.GDvida2Objects1= [];
gdjs.muerteCode.GDvida2Objects2= [];
gdjs.muerteCode.GDvida2Objects3= [];
gdjs.muerteCode.GDNewText3Objects1= [];
gdjs.muerteCode.GDNewText3Objects2= [];
gdjs.muerteCode.GDNewText3Objects3= [];
gdjs.muerteCode.GDvidapouObjects1= [];
gdjs.muerteCode.GDvidapouObjects2= [];
gdjs.muerteCode.GDvidapouObjects3= [];
gdjs.muerteCode.GDarma2Objects1= [];
gdjs.muerteCode.GDarma2Objects2= [];
gdjs.muerteCode.GDarma2Objects3= [];

gdjs.muerteCode.conditionTrue_0 = {val:false};
gdjs.muerteCode.condition0IsTrue_0 = {val:false};
gdjs.muerteCode.condition1IsTrue_0 = {val:false};
gdjs.muerteCode.condition2IsTrue_0 = {val:false};
gdjs.muerteCode.conditionTrue_1 = {val:false};
gdjs.muerteCode.condition0IsTrue_1 = {val:false};
gdjs.muerteCode.condition1IsTrue_1 = {val:false};
gdjs.muerteCode.condition2IsTrue_1 = {val:false};


gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs.muerteCode.GDarmaObjects1});
gdjs.muerteCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.muerteCode.GDpersonajeObjects1, gdjs.muerteCode.GDpersonajeObjects2);


gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects2[k] = gdjs.muerteCode.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects2 */
{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects2[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(gdjs.muerteCode.GDpersonajeObjects1, gdjs.muerteCode.GDpersonajeObjects2);


gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects2.length;i<l;++i) {
    if ( !(gdjs.muerteCode.GDpersonajeObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects2[k] = gdjs.muerteCode.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects2 */
{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.muerteCode.GDpersonajeObjects1, gdjs.muerteCode.GDpersonajeObjects2);

{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects2[i].flipX(true);
}
}}

}


{


gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects1 */
{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects1[i].flipX(false);
}
}}

}


};gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects2Objects = Hashtable.newFrom({"arma": gdjs.muerteCode.GDarmaObjects2});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpouObjects2Objects = Hashtable.newFrom({"pou": gdjs.muerteCode.GDpouObjects2});
gdjs.muerteCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.muerteCode.GDvidaObjects2 */

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDvidaObjects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDvidaObjects2[i].getWidth() <= 0 ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDvidaObjects2[k] = gdjs.muerteCode.GDvidaObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDvidaObjects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpouObjects2 */
{for(var i = 0, len = gdjs.muerteCode.GDpouObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpouObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "victoria", false);
}}

}


};gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects2Objects = Hashtable.newFrom({"arma2": gdjs.muerteCode.GDarma2Objects2});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpersonajeObjects2Objects = Hashtable.newFrom({"personaje": gdjs.muerteCode.GDpersonajeObjects2});
gdjs.muerteCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.muerteCode.GDvida2Objects2 */

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDvida2Objects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDvida2Objects2[i].getWidth() <= 0 ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDvida2Objects2[k] = gdjs.muerteCode.GDvida2Objects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDvida2Objects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lose", false);
}}

}


};gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects2Objects = Hashtable.newFrom({"arma2": gdjs.muerteCode.GDarma2Objects2});
gdjs.muerteCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.muerteCode.GDpouObjects2 */

gdjs.muerteCode.condition0IsTrue_0.val = false;
gdjs.muerteCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpouObjects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpouObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpouObjects2[k] = gdjs.muerteCode.GDpouObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDpouObjects2.length = k;}if ( gdjs.muerteCode.condition0IsTrue_0.val ) {
{
{gdjs.muerteCode.conditionTrue_1 = gdjs.muerteCode.condition1IsTrue_0;
gdjs.muerteCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9293092);
}
}}
if (gdjs.muerteCode.condition1IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpouObjects2 */
gdjs.muerteCode.GDarma2Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects2Objects, (( gdjs.muerteCode.GDpouObjects2.length === 0 ) ? 0 :gdjs.muerteCode.GDpouObjects2[0].getPointX("")), (( gdjs.muerteCode.GDpouObjects2.length === 0 ) ? 0 :gdjs.muerteCode.GDpouObjects2[0].getPointY("")) + 40, "");
}{for(var i = 0, len = gdjs.muerteCode.GDarma2Objects2.length ;i < len;++i) {
    gdjs.muerteCode.GDarma2Objects2[i].setZOrder((( gdjs.muerteCode.GDpouObjects2.length === 0 ) ? 0 :gdjs.muerteCode.GDpouObjects2[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.muerteCode.GDarma2Objects2.length ;i < len;++i) {
    gdjs.muerteCode.GDarma2Objects2[i].getBehavior("Physics2").setLinearVelocityX(-(1000));
}
}}

}


};gdjs.muerteCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("arma"), gdjs.muerteCode.GDarmaObjects2);
gdjs.copyArray(runtimeScene.getObjects("pou"), gdjs.muerteCode.GDpouObjects2);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects2Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpouObjects2Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("vida"), gdjs.muerteCode.GDvidaObjects2);
{for(var i = 0, len = gdjs.muerteCode.GDvidaObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDvidaObjects2[i].setWidth(gdjs.muerteCode.GDvidaObjects2[i].getWidth() - (0.5));
}
}
{ //Subevents
gdjs.muerteCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("arma2"), gdjs.muerteCode.GDarma2Objects2);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects2);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects2Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpersonajeObjects2Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("vida2"), gdjs.muerteCode.GDvida2Objects2);
{for(var i = 0, len = gdjs.muerteCode.GDvida2Objects2.length ;i < len;++i) {
    gdjs.muerteCode.GDvida2Objects2[i].setWidth(gdjs.muerteCode.GDvida2Objects2[i].getWidth() - (5));
}
}
{ //Subevents
gdjs.muerteCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects2);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects2[i].getX() >= 1851 ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects2[k] = gdjs.muerteCode.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("pared"), gdjs.muerteCode.GDparedObjects2);
gdjs.copyArray(runtimeScene.getObjects("pou"), gdjs.muerteCode.GDpouObjects2);
gdjs.copyArray(runtimeScene.getObjects("vida"), gdjs.muerteCode.GDvidaObjects2);
gdjs.copyArray(runtimeScene.getObjects("vidapou"), gdjs.muerteCode.GDvidapouObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, 1900, 0, 2950, 600, "", 0);
}{for(var i = 0, len = gdjs.muerteCode.GDparedObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDparedObjects2[i].setX(1850);
}
}{for(var i = 0, len = gdjs.muerteCode.GDparedObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDparedObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.muerteCode.GDvidaObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDvidaObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.muerteCode.GDvidapouObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDvidapouObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.muerteCode.GDpouObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDpouObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}
{ //Subevents
gdjs.muerteCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects2);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects2.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects2[i].getX() <= 1849 ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects2[k] = gdjs.muerteCode.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects2.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("arma"), gdjs.muerteCode.GDarmaObjects2);
{for(var i = 0, len = gdjs.muerteCode.GDarmaObjects2.length ;i < len;++i) {
    gdjs.muerteCode.GDarmaObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("vida"), gdjs.muerteCode.GDvidaObjects1);
gdjs.copyArray(runtimeScene.getObjects("vidapou"), gdjs.muerteCode.GDvidapouObjects1);
{for(var i = 0, len = gdjs.muerteCode.GDvidaObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDvidaObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.muerteCode.GDvidapouObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDvidapouObjects1[i].hide();
}
}}

}


};gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs.muerteCode.GDarmaObjects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects = Hashtable.newFrom({"arma2": gdjs.muerteCode.GDarma2Objects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs.muerteCode.GDarmaObjects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects = Hashtable.newFrom({"arma": gdjs.muerteCode.GDarmaObjects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects = Hashtable.newFrom({"arma2": gdjs.muerteCode.GDarma2Objects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects = Hashtable.newFrom({"arma2": gdjs.muerteCode.GDarma2Objects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpersonajeObjects1Objects = Hashtable.newFrom({"personaje": gdjs.muerteCode.GDpersonajeObjects1});
gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpouObjects1Objects = Hashtable.newFrom({"pou": gdjs.muerteCode.GDpouObjects1});
gdjs.muerteCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("pared2"), gdjs.muerteCode.GDpared2Objects1);
gdjs.copyArray(runtimeScene.getObjects("piso"), gdjs.muerteCode.GDpisoObjects1);
{for(var i = 0, len = gdjs.muerteCode.GDpisoObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpisoObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.muerteCode.GDpared2Objects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpared2Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
gdjs.muerteCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects1.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects1[i].getBehavior("PlatformerObject").isUsingControl("Down") ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects1[k] = gdjs.muerteCode.GDpersonajeObjects1[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects1.length = k;}if ( gdjs.muerteCode.condition0IsTrue_0.val ) {
{
{gdjs.muerteCode.conditionTrue_1 = gdjs.muerteCode.condition1IsTrue_0;
gdjs.muerteCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9281724);
}
}}
if (gdjs.muerteCode.condition1IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects1 */
gdjs.muerteCode.GDarmaObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects, (( gdjs.muerteCode.GDpersonajeObjects1.length === 0 ) ? 0 :gdjs.muerteCode.GDpersonajeObjects1[0].getPointX("")), (( gdjs.muerteCode.GDpersonajeObjects1.length === 0 ) ? 0 :gdjs.muerteCode.GDpersonajeObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.muerteCode.GDarmaObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarmaObjects1[i].setZOrder((( gdjs.muerteCode.GDpersonajeObjects1.length === 0 ) ? 0 :gdjs.muerteCode.GDpersonajeObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.muerteCode.GDarmaObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarmaObjects1[i].getBehavior("Physics2").setLinearVelocityX(800);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects1.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects1[k] = gdjs.muerteCode.GDpersonajeObjects1[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects1.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects1 */
{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects1.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects1[k] = gdjs.muerteCode.GDpersonajeObjects1[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects1.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.muerteCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.muerteCode.GDpersonajeObjects1.length;i<l;++i) {
    if ( gdjs.muerteCode.GDpersonajeObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.muerteCode.condition0IsTrue_0.val = true;
        gdjs.muerteCode.GDpersonajeObjects1[k] = gdjs.muerteCode.GDpersonajeObjects1[i];
        ++k;
    }
}
gdjs.muerteCode.GDpersonajeObjects1.length = k;}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDpersonajeObjects1 */
{for(var i = 0, len = gdjs.muerteCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpersonajeObjects1[i].setAnimation(2);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);
{gdjs.evtTools.camera.centerCameraWithinLimits(runtimeScene, (gdjs.muerteCode.GDpersonajeObjects1.length !== 0 ? gdjs.muerteCode.GDpersonajeObjects1[0] : null), 0, 0, 1900, 600, true, "", 0);
}}

}


{


gdjs.muerteCode.eventsList4(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("pou"), gdjs.muerteCode.GDpouObjects1);
{for(var i = 0, len = gdjs.muerteCode.GDpouObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDpouObjects1[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("arma"), gdjs.muerteCode.GDarmaObjects1);
gdjs.copyArray(runtimeScene.getObjects("arma2"), gdjs.muerteCode.GDarma2Objects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDarmaObjects1 */
/* Reuse gdjs.muerteCode.GDarma2Objects1 */
{for(var i = 0, len = gdjs.muerteCode.GDarma2Objects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarma2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.muerteCode.GDarmaObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarmaObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("arma"), gdjs.muerteCode.GDarmaObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarmaObjects1Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDarmaObjects1 */
{for(var i = 0, len = gdjs.muerteCode.GDarmaObjects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarmaObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("arma2"), gdjs.muerteCode.GDarma2Objects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDarma2Objects1Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
/* Reuse gdjs.muerteCode.GDarma2Objects1 */
{for(var i = 0, len = gdjs.muerteCode.GDarma2Objects1.length ;i < len;++i) {
    gdjs.muerteCode.GDarma2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.muerteCode.GDpersonajeObjects1);
gdjs.copyArray(runtimeScene.getObjects("pou"), gdjs.muerteCode.GDpouObjects1);

gdjs.muerteCode.condition0IsTrue_0.val = false;
{
gdjs.muerteCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpersonajeObjects1Objects, gdjs.muerteCode.mapOfGDgdjs_46muerteCode_46GDpouObjects1Objects, false, runtimeScene, false);
}if (gdjs.muerteCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("vida2"), gdjs.muerteCode.GDvida2Objects1);
{for(var i = 0, len = gdjs.muerteCode.GDvida2Objects1.length ;i < len;++i) {
    gdjs.muerteCode.GDvida2Objects1[i].setWidth(gdjs.muerteCode.GDvida2Objects1[i].getWidth() - (5));
}
}}

}


};

gdjs.muerteCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.muerteCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.muerteCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.muerteCode.GDNewPanelSpriteObjects3.length = 0;
gdjs.muerteCode.GDpisoObjects1.length = 0;
gdjs.muerteCode.GDpisoObjects2.length = 0;
gdjs.muerteCode.GDpisoObjects3.length = 0;
gdjs.muerteCode.GDparedObjects1.length = 0;
gdjs.muerteCode.GDparedObjects2.length = 0;
gdjs.muerteCode.GDparedObjects3.length = 0;
gdjs.muerteCode.GDpared2Objects1.length = 0;
gdjs.muerteCode.GDpared2Objects2.length = 0;
gdjs.muerteCode.GDpared2Objects3.length = 0;
gdjs.muerteCode.GDpersonajeObjects1.length = 0;
gdjs.muerteCode.GDpersonajeObjects2.length = 0;
gdjs.muerteCode.GDpersonajeObjects3.length = 0;
gdjs.muerteCode.GDNewSprite2Objects1.length = 0;
gdjs.muerteCode.GDNewSprite2Objects2.length = 0;
gdjs.muerteCode.GDNewSprite2Objects3.length = 0;
gdjs.muerteCode.GDNewTextObjects1.length = 0;
gdjs.muerteCode.GDNewTextObjects2.length = 0;
gdjs.muerteCode.GDNewTextObjects3.length = 0;
gdjs.muerteCode.GDarmaObjects1.length = 0;
gdjs.muerteCode.GDarmaObjects2.length = 0;
gdjs.muerteCode.GDarmaObjects3.length = 0;
gdjs.muerteCode.GDpouObjects1.length = 0;
gdjs.muerteCode.GDpouObjects2.length = 0;
gdjs.muerteCode.GDpouObjects3.length = 0;
gdjs.muerteCode.GDNewText2Objects1.length = 0;
gdjs.muerteCode.GDNewText2Objects2.length = 0;
gdjs.muerteCode.GDNewText2Objects3.length = 0;
gdjs.muerteCode.GDvidaObjects1.length = 0;
gdjs.muerteCode.GDvidaObjects2.length = 0;
gdjs.muerteCode.GDvidaObjects3.length = 0;
gdjs.muerteCode.GDvida2Objects1.length = 0;
gdjs.muerteCode.GDvida2Objects2.length = 0;
gdjs.muerteCode.GDvida2Objects3.length = 0;
gdjs.muerteCode.GDNewText3Objects1.length = 0;
gdjs.muerteCode.GDNewText3Objects2.length = 0;
gdjs.muerteCode.GDNewText3Objects3.length = 0;
gdjs.muerteCode.GDvidapouObjects1.length = 0;
gdjs.muerteCode.GDvidapouObjects2.length = 0;
gdjs.muerteCode.GDvidapouObjects3.length = 0;
gdjs.muerteCode.GDarma2Objects1.length = 0;
gdjs.muerteCode.GDarma2Objects2.length = 0;
gdjs.muerteCode.GDarma2Objects3.length = 0;

gdjs.muerteCode.eventsList5(runtimeScene);
return;

}

gdjs['muerteCode'] = gdjs.muerteCode;
