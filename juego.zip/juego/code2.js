gdjs.inicioCode = {};
gdjs.inicioCode.GDNewTiledSpriteObjects1= [];
gdjs.inicioCode.GDNewTiledSpriteObjects2= [];
gdjs.inicioCode.GDNewParticlesEmitterObjects1= [];
gdjs.inicioCode.GDNewParticlesEmitterObjects2= [];
gdjs.inicioCode.GDNewTextObjects1= [];
gdjs.inicioCode.GDNewTextObjects2= [];

gdjs.inicioCode.conditionTrue_0 = {val:false};
gdjs.inicioCode.condition0IsTrue_0 = {val:false};
gdjs.inicioCode.condition1IsTrue_0 = {val:false};


gdjs.inicioCode.eventsList0 = function(runtimeScene) {

{


gdjs.inicioCode.condition0IsTrue_0.val = false;
{
gdjs.inicioCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.inicioCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}}

}


};

gdjs.inicioCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.inicioCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.inicioCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.inicioCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.inicioCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.inicioCode.GDNewTextObjects1.length = 0;
gdjs.inicioCode.GDNewTextObjects2.length = 0;

gdjs.inicioCode.eventsList0(runtimeScene);
return;

}

gdjs['inicioCode'] = gdjs.inicioCode;
